# Introduction

Welcome to your Kafka Connect Neo4j Connector!

# Build it locally

Build the project by running the following command:

    $ mvn clean install

Inside the directory `<neo4j-streams>/kafka-connect-neo4j/target/component/packages` you'll find a file named `neo4j-kafka-connect-neo4j-<VERSION>.zip`

# Run with docker

Please refer to this file [readme.adoc](doc/readme.adoc)
